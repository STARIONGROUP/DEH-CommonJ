var searchData=
[
  ['navigationservice_0',['NavigationService',['../class_services_1_1_navigation_service_1_1_navigation_service.html',1,'Services::NavigationService']]],
  ['newelement_1',['NewElement',['../enum_enumerations_1_1_mapped_element_row_status.html#aa149c83c32b1ba7c0ca23373b9aae563',1,'Enumerations::MappedElementRowStatus']]],
  ['none_2',['None',['../enum_enumerations_1_1_mapped_element_row_status.html#abaf72b3a009ae4dca965ea060fc2ab35',1,'Enumerations::MappedElementRowStatus']]]
];
