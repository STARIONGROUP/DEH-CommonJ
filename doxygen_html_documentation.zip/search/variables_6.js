var searchData=
[
  ['hubcontroller_0',['hubController',['../class_view_models_1_1_dialogs_1_1_mapping_configuration_dialog_view_model.html#aa62d7b40fbd3a9985bdf9473f79f8484',1,'ViewModels.Dialogs.MappingConfigurationDialogViewModel.hubController()'],['../class_view_models_1_1_object_browser_view_model.html#a5b043c30002fcd98c5159eb4f7daa9f7',1,'ViewModels.ObjectBrowserViewModel.hubController()']]],
  ['hubcontroller_1',['HubController',['../class_services_1_1_mapping_configuration_1_1_mapping_configuration_service.html#af662514885dc9a33173323eba27a1f56',1,'Services.MappingConfiguration.MappingConfigurationService.HubController()'],['../class_view_models_1_1_impact_view_panel_view_model.html#a6d4921cd513759314926e78f6e991a9d',1,'ViewModels.ImpactViewPanelViewModel.HubController()']]]
];
