var searchData=
[
  ['userpreference_0',['UserPreference',['../class_services_1_1_user_preference_service_1_1_user_preference.html',1,'Services::UserPreferenceService']]],
  ['userpreferenceservice_1',['UserPreferenceService',['../class_services_1_1_user_preference_service_1_1_user_preference_service.html',1,'Services::UserPreferenceService']]]
];
